function temp(n)
	for i = 0:n
		printf("%d%d%d%d%d%d%d%d%d\n",floor(rand*10),floor(rand*10),floor(rand*10),floor(rand*10),floor(rand*10),floor(rand*10),floor(rand*10),floor(rand*10),floor(rand*10));
	end;
end;