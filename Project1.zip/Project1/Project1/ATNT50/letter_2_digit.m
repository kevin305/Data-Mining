function d = letter_2_digit(string)
	d = lower(string)-96;
  end;