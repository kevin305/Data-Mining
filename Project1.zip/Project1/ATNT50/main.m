function main(type)
	addpath('../matlab');
  %Sample example
  %trainData = load('trainDataXY.txt');
  %testData = load('testDataXY.txt');
  
  %ATNT Photo DataSet
	%data1 = load('../ATNTFaceImages400.txt');
  %[trainData,testData] = partitionData(data1,0.8);
  
  %Hand written letters Dataset
  data1 = load('../HandWrittenLetters.txt');
  [trainData,testData] = partitionData(data1,0.8);
  
	testY = testData(1,:);
  
  % Part-1 --------------KNN Classification---------------------------------------------
	if strfind(type,'knn')>0||strfind(type,'all')>0
	k =5;
	%{
  result = knnclassifier(trainData,testData,k);
  count = size(testY,2);
	%disp(result);
	%disp(testY);
  plotData(testY,result,'KNN Classification');
  c = 0;
  printf('\n');
  printf(' KNN Classification with k:%d -------------------------------\n\n',k);
  for i =1:count
	 if result(1,i)==testY(1,i)
	   c++;
	 end;  
	% printf(' Predicted Value:%d Actual Value:%d \n',result(1,i),testY(1,i));
  end;
  accuracy = c/count*100;
  printf(' Accuracy: %d%%\n',accuracy);
  printf('\n');
  printf(' Press any key to continue..............\n\n');
  pause;
  %}
  accuracy = [];
  
		kfold = 5;
		data = data1;
		l = 1;
		s =  ceil(size(data,2)/kfold);
		q = 1;
		while l<=size(data,2)
	  	%disp(data(1:5,:));
	  	[trainData1,testData1] = partitionData(data,0.8);
	  	result = knnclassifier(trainData1,testData1,k);
	  	%disp(result);
	  	testY1 = testData1(1,:);
	  	count = size(testY1,2);
	  	% plotData(testY,result,'KNN Classification');
	  	c = 0;
	  	printf('\n');
	  	printf(' %d-NN Classification Cross-Validation %d -------------------------------\n\n',k,q);
	  	for i =1:count
				if result(1,i)==testY1(1,i)
			  	c++;
				endif;  
	  	%  printf(' Predicted Value:%d Actual Value:%d \n',result(1,i),testY(1,i));
	  	endfor;
	  	t = c/count*100;
			printf(' Accuracy: %d%%\n',t);
	  	accuracy = [accuracy,t];
	  	l = l+s;
	  	q++;
	  	data = modifyData(data,kfold);
		endwhile;
		%printf(' Accuracy: %d%%\n',accuracy);
		printf('\n');
		printf(' Press any key to continue..............\n\n');
		pause;
  

  end;
  % Part-2 --------------Centroid Method Classification---------------------------------
  
if strfind(type,'cent')>0||strfind(type,'all')>0
  %{
  result = centroidclassifier(trainData,testData);
	count = size(testY,2);
  plotData(testY,result,'Centroid Method Classification');
  c = 0;
  printf('\n');
  printf(' Centroid Method Classification-------------------------------\n\n');
  for i =1:count
	 if result(1,i)==testY(1,i)
	   c++;
	 end;  
	 %printf(' Predicted Value:%d Actual Value:%d \n',result(1,i),testY(1,i));
  end;
  accuracy = c/count*100;
  printf(' Accuracy: %d%%\n',accuracy);
  printf('\n');
  printf(' Press any key to continue..............\n');
  pause;
  %}
  accuracy = [];
	kfold = 5;
	data = data1;
	l = 1;
	s =  ceil(size(data,2)/kfold);
	q = 1;
	while l<=size(data,2)
	  [trainData1,testData1] = partitionData(data,0.8);
	  result = centroidclassifier(trainData1,testData1);
	  testY1 = testData1(1,:);      
	  count = size(testY1,2);
	  %plotData(testY1,result,'Centroid Method Classification');
	  c = 0;
	  printf('\n');
	  printf(' Centroid Method Classification-------------------------------%d\n\n',q);
	  for i =1:count
			if result(1,i)==testY1(1,i)
				c++;
			end;  
		%	printf(' Predicted Value:%d Actual Value:%d \n',result(1,i),testY1(1,i));
	  end;
		t = c/count*100;
		printf(' Accuracy: %d%%\n',t);
		accuracy = [accuracy,t];
		l = l+s;
		q++;
		data = modifyData(data,kfold);
  end;
	%printf(' Accuracy: %d%%\n',accuracy);
	printf('\n');
	printf(' Press any key to continue..............\n\n');
	pause; 
  end;
  
  % Part-3 --------------Linear Regression Classification--------------------------------
if strfind(type,'linear')>0||strfind(type,'all')>0
  %{
	classes = size(unique(trainData(1,:)),2);
  v = ones(1,classes);
  s = diag(v);
  X = trainData(2:size(trainData,1),:);
  
  %disp(size(X));
  Y =[];
  for i = 1:size(trainData,2)
	  Y = [Y,s(:,trainData(1,i))]; 
  end;
  %disp(size(Y));
  minBeta = linearclassifier(X,Y); 
  y = minBeta'*testData(2:size(testData,1),:);
  %gives class number
  %disp(y);
  [~,ind] = max(y);
  count = size(testY,2);
  plotData(testY,ind,'Linear Regression Classification');
  c = 0;
  printf('\n');
  printf(' Linear Regression Classification-------------------------------\n\n');
  disp(classes);
  for i =1:count
	 if ind(1,i)==testY(1,i)
	   c++;
	 end;  
	 %printf(' Predicted Value:%d Actual Value:%d \n',ind(1,i),testY(1,i));
  end;
  accuracy = c/count*100;
  printf(' Accuracy: %d%%\n',accuracy);
  printf('\n');
  printf(' Press any key to continue..............\n\n');
  pause;
 %}
 accuracy = [];
 
	kfold = 5;
	data = data1;
	l = 1;
	s =  ceil(size(data,2)/kfold);
	q = 1;
	while l<size(data,2)
		[trainData1,testData1] = partitionData(data,0.8);
	  classes = size(unique(trainData1(1,:)),2);
  	v = ones(1,classes);
  	sy = diag(v);
  	X = trainData1(2:size(trainData1,1),:);
  
  	%disp(size(X));
  	Y =[];
  	for i = 1:size(trainData1,2)
	  	Y = [Y,sy(:,trainData1(1,i))]; 
  	end;
  	%disp(size(Y));
  	minBeta = linearclassifier(X,Y); 
  	y = minBeta'*testData1(2:size(testData1,1),:);
  	%gives class number
  	%disp(y);
  	[~,ind] = max(y);
	  testY1 = testData1(1,:);      
	  count = size(testY1,2);
	  %plotData(testY1,ind,'Linear Regression Classification');
	  c = 0;
	  printf('\n');
	  printf(' Linear Regression Classification-------------------------------%d\n\n',q);
	  for i =1:count
			if ind(1,i)==testY1(1,i)
				c++;
			end;  
			%printf(' Predicted Value:%d Actual Value:%d \n',ind(1,i),testY1(1,i));
	  end;
		t = c/count*100;
		printf(' Accuracy: %d%%\n',t);
		accuracy = [accuracy,t];
		l = l+s;
		q++;
		data = modifyData(data,kfold);
  end;
	%printf(' Accuracy: %d%%\n',accuracy);
	printf('\n');
	printf(' Press any key to continue..............\n\n');
	pause; 
  end;
  
  % Part-4 --------------SVM Classification-----------------------------------------------
if strfind(type,'svm')>0||strfind(type,'all')>0
   %{
	 trainData(2:size(trainData,1),:) = normalize(trainData);
	 testData(2:size(testData,1),:) = normalize(testData);
	 
	 model = svmtrain(trainData(1,:)',trainData(2:size(trainData,1),:)','');
  %disp(model);
	[predict_label, accuracy, prob_estimates] = svmpredict(testY',testData(2:size(testData,1),:)', model, '');
	plotData(testY,predict_label','SVM Classification');
	%}
	acc = [];
		kfold = 5;
		data = data1;
		l = 1;
		s =  ceil(size(data,2)/kfold);
		q = 1;
		while l<=size(data,2)
	  	[trainData1,testData1] = partitionData(data,0.8);
	  	model = svmtrain(trainData1(1,:)',trainData1(2:size(trainData1,1),:)','');		
	  	testY1 = testData1(1,:);      
  		%disp(model);
  		[predict_label, accuracy, prob_estimates] = svmpredict(testY1',testData1(2:size(testData1,1),:)', model, '');
   		acc = [acc,accuracy(1,1)];
			l = l+s;
	 		data = modifyData(data,kfold);
  	end;
		printf('   All accuracies:\n');
		disp(acc);
	end;

end;
